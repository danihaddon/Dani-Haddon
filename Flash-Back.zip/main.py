from flask import Flask,render_template
app = Flask('app')
# for / root, return Hello Word
@app.route("/")

# Remember from flask import request
# for /request and POST method
def hello_world():

    arr = [
      {
        #Induction
        "PIT_ID": "1",
        "DateTime": "03/09/2019",
        "Event_Title": "Induction",
        "Text": "Our first day at Amazon, meeting all the other apprentices and staff, in Coventry",
        "Image_ID":"../static/images/BHX4.jpg",
        "Video_ID":"",
        "User_ID":"1"
      },
        {
        "PIT_ID": "2",
        "DateTime": "13/09/2019",
        "Event_Title": "Siemens Induction",
        "Text": "First day at the Siemens training site",
        "Image_ID":"/static/images/Siemens.jpg",
        "Video_ID":"",
        "User_ID":"3"
      },
        {
        "PIT_ID": "4",
        "DateTime": "19/09/2019",
        "Event_Title": "We found out that Callum had a HUGE penis",
        "Text": "HIS LARGE PENIS",
        "Image_ID":"",
        "Video_ID":"../static/video/Callums large penis.mp4",
        "User_ID":"3"
     },
      {
        #Tameside Induction
        "PIT_ID": "3",
        "DateTime": "20/09/2019",
        "Event_Title": "Tameside Induction",
        "Text": "Start at Tameside College",
        "Image_ID":"../static/images/Tameside1.jpg",
        "Video_ID":"",
        "User_ID":"1"
      },
      {
        #First Night Out
        "PIT_ID": "4",
        "DateTime": "20/09/2019",
        "Event_Title": "The GAY Village",
        "Text": "Our first night out, Liam loved getting touched up by a man, a quote from him '10/10, would reccommend'",
        "Image_ID":"../static/images/Liam.jpg",
        "Video_ID":"",
        "User_ID":"1"
      },

      
      {
        "PIT_ID": "5",
        "DateTime": "23/09/2019",
        "Event_Title": "First full week at Tameside, met all of our teachers and begun learning!",
        "Text": "Starting College",
        "Image_ID":"../static/images/tameside2.jpg",
        "Video_ID":"",
        "User_ID":"1"
        },
    {
        
        "PIT_ID": "8",
        "DateTime": "15/10/2019",
        "Event_Title": "Brian's topknot",
        "Text": "Brian got rid of his topknot to become a curly perm head",
        "Image_ID":"../static/images/Brian.jpg",
        "Video_ID":"",
        "User_ID":"1"
      },

        {
        "PIT_ID": "7",
        "DateTime": "27/02/2020",
        "Event_Title": "Dani calles it The Room...",
        "Text": "The Room",
        "Image_ID":"",
        "Video_ID":"../static/video/video2.mp4",
        "User_ID":"4"
        },
        

    ]
    
    #return render_template('index.html')
    return render_template('home.html',pits = arr)
  
  
if 'app' == '__main__':
    app.run()

app.run(host='0.0.0.0', port=8081)
